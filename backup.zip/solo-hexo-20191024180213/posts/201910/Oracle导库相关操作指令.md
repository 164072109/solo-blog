title: Oracle导库相关操作指令
date: '2019-10-17 11:54:37'
updated: '2019-10-18 11:01:55'
tags: [Oracle, Windows, 导库, 备份]
permalink: /articles/2019/10/17/1571284477428.html
---

导库一定要保证新建的数据库和源库字符集一样，尤其是使用dblink的时候，建完库，首先检查是否与源数据库一致。
`select userenv('language') from dual;`

常见的几种编码
* SIMPLIFIED CHINESE_CHINA.ZHS16GBK
* SIMPLIFIED CHINESE_CHINA.AL32UTF8
### oracle查询表空间占用情况
```
SELECT a.tablespace_name "表空间名称", 
total / (1024 * 1024) "表空间大小(M)", 
free / (1024 * 1024) "表空间剩余大小(M)", 
(total - free) / (1024 * 1024 ) "表空间使用大小(M)", 
total / (1024 * 1024 * 1024) "表空间大小(G)", 
free / (1024 * 1024 * 1024) "表空间剩余大小(G)", 
(total - free) / (1024 * 1024 * 1024) "表空间使用大小(G)", 
round((total - free) / total, 4) * 100 "使用率 %" 
FROM (SELECT tablespace_name, SUM(bytes) free 
FROM dba_free_space 
GROUP BY tablespace_name) a, 
(SELECT tablespace_name, SUM(bytes) total 
FROM dba_data_files 
GROUP BY tablespace_name) b 
WHERE a.tablespace_name = b.tablespace_name;
```
  
###  创建表空间  /修改表空间
```
create tablespace "RH_PROD" datafile 'D:\app\Administrator\oradata\orcl\RH_PROD_1.DBF' size 500M autoextend on;  
```
```  
alter tablespace "RH_PROD" add datafile 'D:\app\Administrator\oradata\orcl\RH_PROD_2.DBF' size 500M autoextend on;  
```

### 创建用户并赋予默认表空间，赋予dba权限，删除用户
```
create user rh_prod identified by rh_prod default tablespace RH_PROD;
```
```
grant connect,resource,dba to rh_prod;
```
```
drop user rh_prod cascade;
```


### 查询用户下对session会话，杀死会话
```
select username,sid,serial#,paddr from v$session where username='RH_UAT';
```
```
alter system kill session '634,7';
```

### sqlplus登录，重新配置监听命令 删库，建库
```
sqlplus / as sysdba
netca  --重新配置监听  
dbca --删库，建库
```

 ###  创建dblink
```
配置tns，注意别名
D:\app\Administrator\product\11.2.0\dbhome_1\NETWORK\ADMIN\tnsnames.ora
```
```
create public database link mylink connect to rh_prod identified by rh_prod using 'PROD';
```
```
select * from dual@mylink;	--测试是否有效
```
```
drop public database link mylink;	--删除
```



### expdp导出数据
```
create directory MY_DIR as 'd:\dump';	--创建目录
```
```
grant write,read on directory MY_DIR to rh_prod;	--授权
```

```
select * from dba_directories;	--查看是否创建成功
```
```
--1)按用户导
expdp scott/tiger@orcl schemas=scott dumpfile=expdp.dmp DIRECTORY=dpdata1

--2)并行进程parallel
expdp scott/tiger@orcl directory=dpdata1 dumpfile=scott3.dmp parallel=40 job_name=scott3

--3)按表名导
expdp scott/tiger@orcl TABLES=emp,dept dumpfile=expdp.dmp DIRECTORY=dpdata1

--4)按查询条件导
expdp scott/tiger@orcl directory=dpdata1 dumpfile=expdp.dmp Tables=emp query='WHERE deptno=20'

--5)按表空间导
expdp system/manager DIRECTORY=dpdata1 DUMPFILE=tablespace.dmp TABLESPACES=temp,example

--6)导整个数据库
expdp system/manager DIRECTORY=dpdata1 DUMPFILE=full.dmp FULL=y

```
#### 下面这个是带了exclude排除了几张数据量特别大而又不需要数据的，并且加了并行的指令
```
expdp rh_prod/rh_prod@orcl network_link=mylink schemas=rh_prod dumpfile=prd1.dmp,prd2.dmp,prd3.dmp parallel=3 DIRECTORY=MY_DIR logfile=prd_log.log EXCLUDE=TABLE:\"IN (\'SYS_RUNTIME_REQUEST_RECORD\',\'SYS_RUNTIME_EXCEPTION_LOG\',\'SYS_FUN_OPTIONS_HISTORY\',\'ZJ_WFL_INSTANCE_LOG\',\'RH_HLS_WX_LOG\',\'SYS_RUNTIME_REQUEST_DETAIL\')\" 
```
### impdp导入数据
```
--1)导到指定用户下
impdp scott/tiger DIRECTORY=dpdata1 DUMPFILE=expdp.dmp SCHEMAS=scott;

--2)改变表的owner
impdp system/manager DIRECTORY=dpdata1 DUMPFILE=expdp.dmp TABLES=scott.dept REMAP_SCHEMA=scott:system;

--3)导入表空间
impdp system/manager DIRECTORY=dpdata1 DUMPFILE=tablespace.dmp TABLESPACES=example;

--4)导整个数据库
impdb system/manager DIRECTORY=dump_dir DUMPFILE=full.dmp FULL=y;

--5)追加数据
impdp system/manager DIRECTORY=dpdata1 DUMPFILE=expdp.dmp SCHEMAS=system TABLE_EXISTS_ACTION

```
#### 带并行导入，未验证并行对impdp是否有效
```
impdp rh_prod/rh_prod@orcl directory=MY_DIR dumpfile=prd1.dmp,prd2.dmp,prd3.dmp  REMAP_SCHEMA=rh_prod:rh_prod parallel=3 logfile=imp_log.log
```
